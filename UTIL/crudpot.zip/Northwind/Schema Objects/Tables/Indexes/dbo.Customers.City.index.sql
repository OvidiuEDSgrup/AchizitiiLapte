﻿CREATE  INDEX "City" ON "dbo"."Customers"("City")


