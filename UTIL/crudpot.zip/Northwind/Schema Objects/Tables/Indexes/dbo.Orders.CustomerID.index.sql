﻿CREATE  INDEX "CustomerID" ON "dbo"."Orders"("CustomerID")


