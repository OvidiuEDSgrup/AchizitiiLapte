﻿CREATE  INDEX "SupplierID" ON "dbo"."Products"("SupplierID")


