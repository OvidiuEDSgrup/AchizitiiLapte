﻿CREATE  INDEX "PostalCode" ON "dbo"."Customers"("PostalCode")


