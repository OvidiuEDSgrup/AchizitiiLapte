﻿CREATE  INDEX "CompanyName" ON "dbo"."Customers"("CompanyName")


