﻿CREATE  INDEX "CategoryName" ON "dbo"."Categories"("CategoryName")


