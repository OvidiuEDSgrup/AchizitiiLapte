﻿CREATE  INDEX "PostalCode" ON "dbo"."Suppliers"("PostalCode")


