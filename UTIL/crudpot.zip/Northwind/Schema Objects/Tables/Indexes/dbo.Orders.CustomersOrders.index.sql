﻿CREATE  INDEX "CustomersOrders" ON "dbo"."Orders"("CustomerID")


