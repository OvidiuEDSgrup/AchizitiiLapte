﻿CREATE  INDEX "OrdersOrder_Details" ON "dbo"."Order Details"("OrderID")


