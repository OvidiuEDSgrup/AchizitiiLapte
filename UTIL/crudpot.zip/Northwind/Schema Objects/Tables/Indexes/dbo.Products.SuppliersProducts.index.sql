﻿CREATE  INDEX "SuppliersProducts" ON "dbo"."Products"("SupplierID")


