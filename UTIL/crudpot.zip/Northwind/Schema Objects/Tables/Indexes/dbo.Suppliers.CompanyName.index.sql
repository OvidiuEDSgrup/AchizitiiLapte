﻿CREATE  INDEX "CompanyName" ON "dbo"."Suppliers"("CompanyName")


