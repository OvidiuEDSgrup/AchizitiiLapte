﻿CREATE  INDEX "LastName" ON "dbo"."Employees"("LastName")


