﻿CREATE  INDEX "Region" ON "dbo"."Customers"("Region")


