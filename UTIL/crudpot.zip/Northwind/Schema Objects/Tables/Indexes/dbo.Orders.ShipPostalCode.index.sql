﻿CREATE  INDEX "ShipPostalCode" ON "dbo"."Orders"("ShipPostalCode")


