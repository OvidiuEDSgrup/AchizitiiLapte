﻿CREATE  INDEX "CategoriesProducts" ON "dbo"."Products"("CategoryID")


