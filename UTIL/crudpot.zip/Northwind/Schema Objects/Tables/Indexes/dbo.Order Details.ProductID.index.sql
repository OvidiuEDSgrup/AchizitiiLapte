﻿CREATE  INDEX "ProductID" ON "dbo"."Order Details"("ProductID")


