﻿CREATE  INDEX "ShippersOrders" ON "dbo"."Orders"("ShipVia")


