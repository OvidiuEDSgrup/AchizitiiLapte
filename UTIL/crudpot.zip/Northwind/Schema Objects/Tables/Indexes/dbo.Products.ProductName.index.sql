﻿CREATE  INDEX "ProductName" ON "dbo"."Products"("ProductName")


