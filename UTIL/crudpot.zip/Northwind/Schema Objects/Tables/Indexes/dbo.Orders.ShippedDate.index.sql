﻿CREATE  INDEX "ShippedDate" ON "dbo"."Orders"("ShippedDate")


