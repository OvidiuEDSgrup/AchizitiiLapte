﻿CREATE  INDEX "CategoryID" ON "dbo"."Products"("CategoryID")


